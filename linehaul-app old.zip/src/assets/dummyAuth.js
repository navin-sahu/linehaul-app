export const adminCredentials = {
  username: "admin",
  password: "40Sfs$Y#8!",
};

export const driverCredentials = {
  username: "driver",
  password: "*2iwLrWm31",
};
