import "../css/DriverDashboard.css"
const driverData = {
  name: "John Driver",
  trailer: "TR-458",
  route: "Wellington → Auckland",
  loadplanStatus: "Completed",
};

const DriverDashboard = () => {
  return (
    <div className="welcome-wrapper">
      <div className="welcome-card">
        <h1>Driver Dashboard</h1>
      </div>
    </div>
  );
};

export default DriverDashboard;
