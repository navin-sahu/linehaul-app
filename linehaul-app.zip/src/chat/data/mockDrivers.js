export const mockDrivers = [
  { id: "d1", name: "Motu", unread: 2 },
  { id: "d2", name: "Frank", unread: 0 },
  { id: "d3", name: "John", unread: 5 }
];
