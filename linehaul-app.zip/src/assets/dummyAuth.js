export const adminCredentials = {
  username: "admin",
  password: "40Sfs$Y#8!",
};

export const driverCredentials = [
  { username: "john", password: "*2iwLrWm31", name: "John" },
  { username: "frank", password: "*2iwLrWm31", name: "Frank" },
  { username: "aman", password: "*2iwLrWm31", name: "Aman" },
  { username: "ravi", password: "*2iwLrWm31", name: "Ravi" },
  { username: "cas", password: "*2iwLrWm31", name: "CAS" },
  { username: "simon", password: "*2iwLrWm31", name: "Simon" },
  { username: "luke", password: "*2iwLrWm31", name: "Luke" },
  { username: "arshpreet", password: "*2iwLrWm31", name: "Arshpreet" },
  { username: "kartic", password: "*2iwLrWm31", name: "Kartic" },
  { username: "jaspreet", password: "*2iwLrWm31", name: "Jaspreet" },
  { username: "nikhil", password: "*2iwLrWm31", name: "Nikhil" },
  { username: "ben", password: "*2iwLrWm31", name: "Ben" },
  { username: "keith", password: "*2iwLrWm31", name: "Keith" },
  { username: "travis", password: "*2iwLrWm31", name: "Travis" },
  { username: "jordan", password: "*2iwLrWm31", name: "Jordan" },
  { username: "paul", password: "*2iwLrWm31", name: "Paul" },
  { username: "aaron", password: "*2iwLrWm31", name: "Aaron" },
  { username: "sam", password: "*2iwLrWm31", name: "Sam" }
];

